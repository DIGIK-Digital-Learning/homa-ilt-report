// See the Electron documentation for details on how to use preload scripts:
// https://www.electronjs.org/docs/latest/tutorial/process-model#preload-scripts

import { contextBridge, ipcRenderer } from "electron";

contextBridge.exposeInMainWorld("electronAPI", {
  selectExcel: (): Promise<SelectExcelResult> =>
    ipcRenderer.invoke("excel:select"),

  // onCourseProgress: (
  //   callback: (progress: {
  //     current: number;
  //     total: number;
  //     remaining: number;
  //   }) => void,
  // ) => {
  //   ipcRenderer.on("courses:progress", (_event, progress) => {
  //     callback(progress);
  //   });
  // },

  onAnalysisProgress: (callback: (progress: AnalysisProgress) => void) => {
    ipcRenderer.on("analysis:progress", (_event, progress) => {
      callback(progress);
    });
  },

  // testTalentLms: (): Promise<TalentLmsTestResult> =>
  //   ipcRenderer.invoke("talentlms:test"),
});
