import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";

type ActiveView = "summary" | "courses" | "users";

function App() {
  const [summary, setSummary] = useState<ExcelSummary | null>(null);
  const [analysisProgress, setAnalysisProgress] =
    useState<AnalysisProgress | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [activeView, setActiveView] = useState<ActiveView>("summary");
  const [openCourses, setOpenCourses] = useState<Set<number>>(new Set());
  const [openUnits, setOpenUnits] = useState<Set<string>>(new Set());

  const progressPercentage =
    analysisProgress && analysisProgress.total > 0
      ? Math.round((analysisProgress.current / analysisProgress.total) * 100)
      : 0;

  useEffect(() => {
    window.electronAPI.onAnalysisProgress((progress) => {
      setAnalysisProgress(progress);
    });
  }, []);

  const handleSelectExcel = async (): Promise<void> => {
    setIsLoading(true);
    setError(null);
    setSummary(null);
    setActiveView("summary");
    setAnalysisProgress(null);
    setOpenCourses(new Set());
    setOpenUnits(new Set());

    try {
      const result = await window.electronAPI.selectExcel();

      if (result.cancelled) {
        return;
      }

      if (result.error) {
        setError(result.error);
        return;
      }

      if (result.summary) {
        setSummary(result.summary);
      }
    } catch (selectionError) {
      console.error(selectionError);
      setError("Ocorreu um erro inesperado ao selecionar o relatório.");
    } finally {
      setIsLoading(false);
    }
  };

  const getProgressDetail = (): string | null => {
    if (!analysisProgress || analysisProgress.total === 0) {
      return null;
    }

    switch (analysisProgress.stage) {
      case "processingExcel":
        return `${analysisProgress.current.toLocaleString("pt-PT")} de ${analysisProgress.total.toLocaleString("pt-PT")} linhas`;

      case "matchingCourses":
        return `${analysisProgress.current.toLocaleString("pt-PT")} de ${analysisProgress.total.toLocaleString("pt-PT")} cursos`;

      case "checkingIlt":
        return `${analysisProgress.current.toLocaleString("pt-PT")} de ${analysisProgress.total.toLocaleString("pt-PT")} cursos verificados`;

      case "fetchingIltUnits":
        return `${analysisProgress.current.toLocaleString("pt-PT")} de ${analysisProgress.total.toLocaleString("pt-PT")} cursos ILT analisados`;

      case "checkingUsers":
        return `${analysisProgress.current.toLocaleString("pt-PT")} de ${analysisProgress.total.toLocaleString("pt-PT")} registos ILT analisados`;

      case "matchingUsers":
        return `${analysisProgress.current.toLocaleString("pt-PT")} de ${analysisProgress.total.toLocaleString("pt-PT")} colaboradores`;

      case "checkingUnitProgress":
        return `${analysisProgress.current.toLocaleString("pt-PT")} de ${analysisProgress.total.toLocaleString("pt-PT")} verificações de progresso`;

      default:
        return null;
    }
  };

  const getProgressText = (): string => {
    switch (analysisProgress?.stage) {
      case "reading":
        return "A abrir o ficheiro Excel...";

      case "processingExcel":
        return "A analisar as linhas do relatório...";

      case "fetchingCourses":
        return "A obter os cursos da TalentLMS...";

      case "matchingCourses":
        return "A associar os cursos à TalentLMS...";

      case "checkingIlt":
        return "A verificar os cursos com formação ILT...";

      case "fetchingIltUnits":
        return "A identificar as unidades ILT dos cursos...";

      case "checkingUsers":
        return "A identificar os colaboradores dos cursos ILT...";

      case "matchingUsers":
        return "A associar os colaboradores à TalentLMS...";

      case "checkingUnitProgress":
        return "A verificar o progresso das unidades ILT...";

      default:
        return "A preparar análise...";
    }
  };

  const getStatusLabel = (status: string): string => {
    switch (status) {
      case "completed":
        return "Concluído";
      case "failed":
        return "Não concluído";
      case "pending":
        return "Pendente";
      case "not_attempted":
        return "Não iniciado";
      case "not_enrolled":
        return "Sem inscrição";
      case "not_checked":
        return "Não verificado";
      case "user_not_found":
        return "Utilizador não encontrado";
      default:
        return status;
    }
  };

  const formatTime = (seconds: number): string => {
    if (!seconds || seconds <= 0) {
      return "—";
    }

    const hours = Math.floor(seconds / 3600);
    const minutes = Math.round((seconds % 3600) / 60);

    if (hours > 0 && minutes > 0) {
      return `${hours}h ${minutes}m`;
    }

    if (hours > 0) {
      return `${hours}h`;
    }

    return `${minutes}m`;
  };

  const getFullName = (user: CourseProgressUser): string => {
    const fullName = `${user.firstName} ${user.lastName}`.trim();

    return fullName || `Colaborador ${user.employeeNumber}`;
  };

  const getStatusCounts = (users: CourseProgressUser[]) => {
    const counts = {
      completed: 0,
      failed: 0,
      pending: 0,
      notAttempted: 0,
      notEnrolled: 0,
      notChecked: 0,
      userNotFound: 0,
    };

    for (const user of users) {
      switch (user.status) {
        case "completed":
          counts.completed++;
          break;
        case "failed":
          counts.failed++;
          break;
        case "pending":
          counts.pending++;
          break;
        case "not_attempted":
          counts.notAttempted++;
          break;
        case "not_enrolled":
          counts.notEnrolled++;
          break;
        case "user_not_found":
          counts.userNotFound++;
          break;
        default:
          counts.notChecked++;
          break;
      }
    }

    return counts;
  };

  const toggleCourse = (courseId: number) => {
    setOpenCourses((current) => {
      const next = new Set(current);

      if (next.has(courseId)) {
        next.delete(courseId);
      } else {
        next.add(courseId);
      }

      return next;
    });
  };

  const toggleUnit = (courseId: number, unitId: number) => {
    const key = `${courseId}-${unitId}`;

    setOpenUnits((current) => {
      const next = new Set(current);

      if (next.has(key)) {
        next.delete(key);
      } else {
        next.add(key);
      }

      return next;
    });
  };

  const totalIltUnits = useMemo(() => {
    if (!summary) {
      return 0;
    }

    return summary.courseProgressDetails.reduce(
      (total, course) => total + course.units.length,
      0,
    );
  }, [summary]);

  return (
    <main className="app">
      <header className="header">
        <span className="product-label">TalentLMS</span>
        <h1>Análise de formação ILT</h1>
        <p>
          Importe o relatório da TalentLMS para identificar os cursos ILT,
          respetivas unidades e o progresso dos colaboradores.
        </p>
      </header>

      <section className="import-panel">
        <div className="excel-icon">XLSX</div>

        <div className="import-copy">
          <h2>{summary ? "Relatório analisado" : "Importar relatório"}</h2>
          <p className="secondary-text">
            O ficheiro original não será alterado.
          </p>
        </div>

        <button
          type="button"
          className="primary-button"
          onClick={handleSelectExcel}
          disabled={isLoading}
        >
          {isLoading
            ? "A analisar..."
            : summary
              ? "Analisar outro relatório"
              : "Selecionar ficheiro Excel"}
        </button>
      </section>

      {isLoading && analysisProgress && (
        <section className="progress-panel">
          <div className="progress-copy">
            <strong>{getProgressText()}</strong>
            {getProgressDetail() && <span>{getProgressDetail()}</span>}
          </div>

          {analysisProgress.total > 0 && (
            <div className="progress-row">
              <progress
                value={analysisProgress.current}
                max={analysisProgress.total}
              />
              <strong>{progressPercentage}%</strong>
            </div>
          )}
        </section>
      )}

      {error && (
        <section className="message error-message">
          <strong>Não foi possível concluir a análise.</strong>
          <span>{error}</span>
        </section>
      )}

      {summary && (
        <section className="summary-panel">
          <div className="file-heading">
            <div className="file-title-wrap">
              <span className="section-label">Análise concluída</span>
              <h2>{summary.fileName}</h2>
            </div>

            <span className="success-badge">Relatório válido</span>
          </div>

          <nav className="view-tabs" aria-label="Vistas da análise">
            <button
              type="button"
              className={activeView === "summary" ? "active" : ""}
              onClick={() => setActiveView("summary")}
            >
              Resumo
            </button>

            <button
              type="button"
              className={activeView === "courses" ? "active" : ""}
              onClick={() => setActiveView("courses")}
            >
              Cursos ILT
            </button>

            <button
              type="button"
              className={activeView === "users" ? "active" : ""}
              onClick={() => setActiveView("users")}
            >
              Colaboradores
            </button>
          </nav>

          {activeView === "summary" && (
            <div className="view-content">
              <div className="stats four-columns">
                <div className="stat">
                  <span>Registos analisados</span>
                  <strong>{summary.totalRows.toLocaleString("pt-PT")}</strong>
                </div>

                <div className="stat">
                  <span>Cursos no relatório</span>
                  <strong>{summary.courses.length}</strong>
                </div>

                <div className="stat">
                  <span>Cursos ILT</span>
                  <strong>{summary.courseProgressDetails.length}</strong>
                </div>

                <div className="stat">
                  <span>Unidades ILT</span>
                  <strong>{totalIltUnits}</strong>
                </div>
              </div>

              <div className="stats three-columns compact-stats">
                <div className="stat">
                  <span>Colaboradores ILT</span>
                  <strong>{summary.uniqueUsers.toLocaleString("pt-PT")}</strong>
                </div>

                <div className="stat">
                  <span>Associados à TalentLMS</span>
                  <strong>
                    {summary.matchedUsers.toLocaleString("pt-PT")}
                  </strong>
                </div>

                <div className="stat">
                  <span>Não encontrados</span>
                  <strong>{summary.unmatchedUsers.length}</strong>
                </div>
              </div>

              {summary.progressStats.processedJobs <
                summary.progressStats.totalJobs && (
                <div className="message info-message">
                  <strong>Modo de teste ativo</strong>
                  <span>
                    Foram verificadas {summary.progressStats.processedJobs} de{" "}
                    {summary.progressStats.totalJobs.toLocaleString("pt-PT")}{" "}
                    combinações colaborador/unidade. Os restantes aparecem como
                    “Não verificado”.
                  </span>
                </div>
              )}

              {summary.unmatchedCourses.length > 0 && (
                <div className="message warning-message">
                  <strong>
                    {summary.unmatchedCourses.length === 1
                      ? "1 curso não foi encontrado na TalentLMS."
                      : `${summary.unmatchedCourses.length} cursos não foram encontrados na TalentLMS.`}
                  </strong>

                  <ul>
                    {summary.unmatchedCourses.map((course) => (
                      <li key={course}>{course}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}

          {activeView === "courses" && (
            <div className="view-content">
              <div className="view-heading">
                <div>
                  <span className="section-label">Formação ILT</span>
                  <h3>Cursos, unidades e colaboradores</h3>
                  <p className="secondary-text">
                    Abra um curso e depois uma unidade para consultar quem
                    concluiu, não iniciou ou não está inscrito.
                  </p>
                </div>

                <span className="count-badge">
                  {summary.courseProgressDetails.length} cursos
                </span>
              </div>

              {summary.progressStats.notChecked > 0 && (
                <div className="message info-message slim-message">
                  <strong>Existem verificações ainda não processadas.</strong>
                  <span>
                    Enquanto o modo de teste estiver ativo, alguns colaboradores
                    aparecem como “Não verificado”.
                  </span>
                </div>
              )}

              <div className="course-list">
                {summary.courseProgressDetails.map((course) => {
                  const isCourseOpen = openCourses.has(course.courseId);
                  const participantNumbers = new Set(
                    course.units.flatMap((unit) =>
                      unit.users.map((user) => user.employeeNumber),
                    ),
                  );

                  const allCourseUsers = course.units.flatMap(
                    (unit) => unit.users,
                  );
                  const courseCounts = getStatusCounts(allCourseUsers);

                  return (
                    <article className="course-card" key={course.courseId}>
                      <button
                        type="button"
                        className="course-toggle"
                        onClick={() => toggleCourse(course.courseId)}
                        aria-expanded={isCourseOpen}
                      >
                        <div className="course-main-info">
                          <span className="course-tag">ILT</span>
                          <div>
                            <h4>{course.courseName}</h4>
                            <span className="course-meta">
                              {course.units.length}{" "}
                              {course.units.length === 1
                                ? "unidade"
                                : "unidades"}
                              <span aria-hidden="true">•</span>
                              {participantNumbers.size.toLocaleString(
                                "pt-PT",
                              )}{" "}
                              colaboradores
                            </span>
                          </div>
                        </div>

                        <div className="course-summary-side">
                          <div className="mini-statuses">
                            {courseCounts.completed > 0 && (
                              <span className="mini-status completed">
                                {courseCounts.completed} concluídos
                              </span>
                            )}

                            {courseCounts.notAttempted > 0 && (
                              <span className="mini-status pending">
                                {courseCounts.notAttempted} não iniciados
                              </span>
                            )}
                          </div>

                          <span
                            className={`chevron ${isCourseOpen ? "open" : ""}`}
                          >
                            ›
                          </span>
                        </div>
                      </button>

                      {isCourseOpen && (
                        <div className="course-body">
                          {course.units.length === 0 ? (
                            <div className="empty-state compact-empty">
                              Não foram encontradas unidades ILT neste curso.
                            </div>
                          ) : (
                            course.units.map((unit) => {
                              const unitKey = `${course.courseId}-${unit.unitId}`;
                              const isUnitOpen = openUnits.has(unitKey);
                              const counts = getStatusCounts(unit.users);

                              return (
                                <section
                                  className="unit-card"
                                  key={unit.unitId}
                                >
                                  <button
                                    type="button"
                                    className="unit-toggle"
                                    onClick={() =>
                                      toggleUnit(course.courseId, unit.unitId)
                                    }
                                    aria-expanded={isUnitOpen}
                                  >
                                    <div className="unit-title-wrap">
                                      <span className="unit-marker" />
                                      <div>
                                        <strong>{unit.unitName}</strong>
                                        <span>
                                          {unit.users.length.toLocaleString(
                                            "pt-PT",
                                          )}{" "}
                                          colaboradores
                                        </span>
                                      </div>
                                    </div>

                                    <div className="unit-summary">
                                      <span className="unit-completed">
                                        {counts.completed} concluídos
                                      </span>
                                      <span
                                        className={`chevron small ${isUnitOpen ? "open" : ""}`}
                                      >
                                        ›
                                      </span>
                                    </div>
                                  </button>

                                  {isUnitOpen && (
                                    <div className="participant-table-wrap">
                                      <div className="participant-table-header">
                                        <span>Colaborador</span>
                                        <span>Estado</span>
                                        <span>Tempo</span>
                                      </div>

                                      <div className="participant-list">
                                        {unit.users.map((user) => (
                                          <div
                                            className="participant-row"
                                            key={`${unit.unitId}-${user.employeeNumber}`}
                                          >
                                            <div className="participant-person">
                                              <span className="person-avatar">
                                                {(
                                                  user.firstName ||
                                                  user.employeeNumber
                                                )
                                                  .slice(0, 2)
                                                  .toUpperCase()}
                                              </span>

                                              <div>
                                                <strong>
                                                  {getFullName(user)}
                                                </strong>
                                                <span>
                                                  #{user.employeeNumber} - #
                                                  {user.talentLmsUserId}
                                                </span>
                                              </div>
                                            </div>

                                            <div>
                                              <span
                                                className={`status-badge status-${user.status}`}
                                              >
                                                {getStatusLabel(user.status)}
                                              </span>
                                            </div>

                                            <span className="time-value">
                                              {formatTime(user.totalTime)}
                                            </span>
                                          </div>
                                        ))}
                                      </div>
                                    </div>
                                  )}
                                </section>
                              );
                            })
                          )}
                        </div>
                      )}
                    </article>
                  );
                })}
              </div>
            </div>
          )}

          {activeView === "users" && (
            <div className="view-content">
              <div className="view-heading">
                <div>
                  <span className="section-label">Validação</span>
                  <h3>Associação de colaboradores</h3>
                  <p className="secondary-text">
                    Esta vista serve apenas para validar a correspondência entre
                    o número de colaborador do Excel e o utilizador da
                    TalentLMS.
                  </p>
                </div>
              </div>

              <div className="stats three-columns">
                <div className="stat">
                  <span>Colaboradores únicos</span>
                  <strong>{summary.uniqueUsers.toLocaleString("pt-PT")}</strong>
                </div>

                <div className="stat">
                  <span>Associados</span>
                  <strong>
                    {summary.matchedUsers.toLocaleString("pt-PT")}
                  </strong>
                </div>

                <div className="stat">
                  <span>Não encontrados</span>
                  <strong>
                    {summary.unmatchedUsers.length.toLocaleString("pt-PT")}
                  </strong>
                </div>
              </div>

              {summary.unmatchedUsers.length === 0 ? (
                <div className="message success-message">
                  <strong>Todos os colaboradores foram associados.</strong>
                  <span>
                    Os números de colaborador foram encontrados na TalentLMS.
                  </span>
                </div>
              ) : (
                <div className="message warning-message">
                  <strong>
                    {summary.unmatchedUsers.length === 1
                      ? "1 colaborador não foi encontrado."
                      : `${summary.unmatchedUsers.length} colaboradores não foram encontrados.`}
                  </strong>

                  <ul className="employee-number-list">
                    {summary.unmatchedUsers.map((employeeNumber) => (
                      <li key={employeeNumber}>#{employeeNumber}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}
        </section>
      )}

      <footer>Os dados são processados localmente neste computador.</footer>
    </main>
  );
}

const rootElement = document.getElementById("root");

if (!rootElement) {
  throw new Error("Não foi encontrado o elemento #root");
}

createRoot(rootElement).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
