import { app, BrowserWindow, dialog, ipcMain } from "electron";
import path from "node:path";
import started from "electron-squirrel-startup";
import ExcelJS from "exceljs";

import {
  getAllCourses,
  isCourseIlt,
  getUserIdByEmployeeNumber,
  getCourseIltUnits,
  getUnitProgress,
} from "./services/talentlms";

declare const MAIN_WINDOW_WEBPACK_ENTRY: string;
declare const MAIN_WINDOW_PRELOAD_WEBPACK_ENTRY: string;

if (started) {
  app.quit();
}

const createWindow = (): void => {
  const mainWindow = new BrowserWindow({
    height: 720,
    width: 960,
    minHeight: 600,
    minWidth: 760,
    maximizable: false,
    resizable: false,
    webPreferences: {
      preload: MAIN_WINDOW_PRELOAD_WEBPACK_ENTRY,
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  mainWindow.loadURL(MAIN_WINDOW_WEBPACK_ENTRY);

  // mainWindow.webContents.openDevTools();
};

function normalizeCourseName(name: string): string {
  return name.trim().toLocaleLowerCase("pt-PT");
}

function normalizeUnitName(name: string): string {
  return name
    .normalize("NFKC")
    .replace(/\s+/gu, " ")
    .trim()
    .toLocaleLowerCase("pt-PT");
}

const HEADER_ROW = 4;
const DATA_START_ROW = HEADER_ROW + 1;

/*
 * Enquanto estiveres a desenvolver o UI deixa true.
 * Quando quiseres uma análise completa, muda para false.
 */
const IS_DEV_TEST = false;
const DEV_PROGRESS_LIMIT = 20;

const talentLmsConfig = {
  baseUrl: "https://homaacademy.talentlms.com",
  apiKey: process.env.TALENTLMS_API_KEY ?? "hzPDxPPXpUWL9rsbsNE19nLvSErbNX",
  apiVersion: "2025-01-01",
};

interface IltUnitData {
  id: number;
  name: string;
}

interface CourseAnalysisData {
  rows: number[];
  talentLmsId: number | null;
  isIlt: boolean | null;
  iltUnits: IltUnitData[];
}

interface UserIltProgressData {
  courseId: number;
  courseName: string;
  unitId: number;
  unitName: string;
  status: string;
  totalTime: number;
}

interface UserAnalysisData {
  rows: number[];
  firstName: string;
  lastName: string;
  talentLmsUserId: number | null;
  iltProgress: UserIltProgressData[];
}

interface CourseProgressUser {
  employeeNumber: string;
  firstName: string;
  lastName: string;
  talentLmsUserId: number | null;
  status: string;
  totalTime: number;
}

interface CourseProgressUnit {
  unitId: number;
  unitName: string;
  users: CourseProgressUser[];
}

interface CourseProgressDetails {
  courseId: number;
  courseName: string;
  units: CourseProgressUnit[];
}

let currentAnalysis: {
  filePath: string;
  workbook: ExcelJS.Workbook;
  worksheet: ExcelJS.Worksheet;
  courses: Map<string, CourseAnalysisData>;
  users: Map<string, UserAnalysisData>;
} | null = null;

ipcMain.handle("excel:select", async (event): Promise<SelectExcelResult> => {
  const result = await dialog.showOpenDialog({
    title: "Selecionar relatório TalentLMS",
    buttonLabel: "Selecionar relatório",
    properties: ["openFile"],
    filters: [
      {
        name: "Ficheiros Excel",
        extensions: ["xlsx"],
      },
    ],
  });

  if (result.canceled || result.filePaths.length === 0) {
    return {
      cancelled: true,
    };
  }

  if (!talentLmsConfig.apiKey) {
    return {
      cancelled: false,
      error:
        "A API key da TalentLMS não está configurada. Define TALENTLMS_API_KEY antes de iniciar a aplicação.",
    };
  }

  const filePath = result.filePaths[0];

  try {
    /* =====================================================
     * 1. ABRIR EXCEL
     * ===================================================== */

    const workbook = new ExcelJS.Workbook();

    event.sender.send("analysis:progress", {
      stage: "reading",
      current: 0,
      total: 0,
    });

    await workbook.xlsx.readFile(filePath);

    const worksheet = workbook.worksheets[0];

    if (!worksheet) {
      return {
        cancelled: false,
        error: "O ficheiro Excel não contém nenhuma folha.",
      };
    }

    /* =====================================================
     * 2. IDENTIFICAR COLUNAS
     * ===================================================== */

    const columns: string[] = [];

    let courseColumnNumber: number | null = null;
    let employeeColumnNumber: number | null = null;
    let firstNameColumnNumber: number | null = null;
    let lastNameColumnNumber: number | null = null;

    worksheet.getRow(HEADER_ROW).eachCell(
      {
        includeEmpty: false,
      },
      (cell, columnNumber) => {
        const columnName = cell.text.trim();
        const normalizedColumnName = columnName.toLocaleLowerCase("pt-PT");

        if (columnName) {
          columns.push(columnName);
        }

        if (normalizedColumnName === "curso") {
          courseColumnNumber = columnNumber;
        }

        if (normalizedColumnName === "número de colaborador") {
          employeeColumnNumber = columnNumber;
        }

        if (normalizedColumnName === "nome") {
          firstNameColumnNumber = columnNumber;
        }

        if (normalizedColumnName === "sobrenome") {
          lastNameColumnNumber = columnNumber;
        }
      },
    );

    if (courseColumnNumber === null) {
      return {
        cancelled: false,
        error: 'Não foi encontrada a coluna "Curso".',
      };
    }

    if (employeeColumnNumber === null) {
      return {
        cancelled: false,
        error: 'Não foi encontrada a coluna "Número de Colaborador".',
      };
    }

    /* =====================================================
     * 3. CONSTRUIR MAP DOS CURSOS
     * ===================================================== */

    const courses = new Map<string, CourseAnalysisData>();

    const totalRows = worksheet.actualRowCount - DATA_START_ROW + 1;

    for (
      let rowNumber = DATA_START_ROW;
      rowNumber <= worksheet.actualRowCount;
      rowNumber++
    ) {
      const row = worksheet.getRow(rowNumber);
      const courseName = row.getCell(courseColumnNumber).text.trim();

      if (courseName) {
        const existingCourse = courses.get(courseName);

        if (existingCourse) {
          existingCourse.rows.push(rowNumber);
        } else {
          courses.set(courseName, {
            rows: [rowNumber],
            talentLmsId: null,
            isIlt: null,
            iltUnits: [],
          });
        }
      }

      const current = rowNumber - DATA_START_ROW + 1;

      if (current % 500 === 0 || current === totalRows) {
        event.sender.send("analysis:progress", {
          stage: "processingExcel",
          current,
          total: totalRows,
        });

        await new Promise<void>((resolve) => setImmediate(resolve));
      }
    }

    const uniqueCourses = Array.from(courses.keys());

    if (!uniqueCourses.length) {
      return {
        cancelled: false,
        error: "Não foram encontrados cursos no relatório.",
      };
    }

    /* =====================================================
     * 4. OBTER CURSOS DA TALENTLMS
     * ===================================================== */

    event.sender.send("analysis:progress", {
      stage: "fetchingCourses",
      current: 0,
      total: 0,
    });

    const talentLmsCourses = await getAllCourses(talentLmsConfig);

    const talentLmsCoursesByName = new Map(
      talentLmsCourses.map((course) => [
        normalizeCourseName(course.name),
        course,
      ]),
    );

    /* =====================================================
     * 5. ASSOCIAR COURSE NAME -> TALENTLMS ID
     * ===================================================== */

    const totalCoursesToMatch = courses.size;
    let currentCourse = 0;

    for (const [courseName, courseData] of courses) {
      const talentLmsCourse = talentLmsCoursesByName.get(
        normalizeCourseName(courseName),
      );

      if (talentLmsCourse) {
        courseData.talentLmsId = talentLmsCourse.id;
      }

      currentCourse++;

      event.sender.send("analysis:progress", {
        stage: "matchingCourses",
        current: currentCourse,
        total: totalCoursesToMatch,
      });

      await new Promise<void>((resolve) => setImmediate(resolve));
    }

    /* =====================================================
     * 6. VERIFICAR QUAIS OS CURSOS ILT
     * ===================================================== */

    const coursesWithId = Array.from(courses.values()).filter(
      (courseData) => courseData.talentLmsId !== null,
    );

    let checkedCourses = 0;
    const COURSE_BATCH_SIZE = 2;

    for (let i = 0; i < coursesWithId.length; i += COURSE_BATCH_SIZE) {
      const batch = coursesWithId.slice(i, i + COURSE_BATCH_SIZE);

      const results = await Promise.all(
        batch.map(async (courseData) => {
          if (courseData.talentLmsId === null) {
            return {
              courseData,
              isIlt: false,
            };
          }

          const isIlt = await isCourseIlt(
            talentLmsConfig,
            courseData.talentLmsId,
          );

          return {
            courseData,
            isIlt,
          };
        }),
      );

      for (const item of results) {
        item.courseData.isIlt = item.isIlt;
        checkedCourses++;

        event.sender.send("analysis:progress", {
          stage: "checkingIlt",
          current: checkedCourses,
          total: coursesWithId.length,
        });
      }
    }

    /* =====================================================
     * 7. CURSOS ILT
     * ===================================================== */

    const iltCoursesData = Array.from(courses.values()).filter(
      (courseData) => courseData.isIlt === true,
    );

    const iltCourses = Array.from(courses.entries())
      .filter(([, courseData]) => courseData.isIlt === true)
      .map(([courseName]) => courseName);

    /* =====================================================
     * 8. OBTER AS UNITS ILT DE CADA CURSO
     * ===================================================== */

    let checkedIltUnits = 0;
    const ILT_UNIT_BATCH_SIZE = 2;

    for (let i = 0; i < iltCoursesData.length; i += ILT_UNIT_BATCH_SIZE) {
      const batch = iltCoursesData.slice(i, i + ILT_UNIT_BATCH_SIZE);

      const results = await Promise.all(
        batch.map(async (courseData) => {
          if (courseData.talentLmsId === null) {
            return {
              courseData,
              units: [] as IltUnitData[],
            };
          }

          const units = await getCourseIltUnits(
            talentLmsConfig,
            courseData.talentLmsId,
          );

          return {
            courseData,
            units,
          };
        }),
      );

      for (const item of results) {
        item.courseData.iltUnits = item.units;
        checkedIltUnits++;

        event.sender.send("analysis:progress", {
          stage: "fetchingIltUnits",
          current: checkedIltUnits,
          total: iltCoursesData.length,
        });
      }
    }

    const iltCourseDetails = Array.from(courses.entries())
      .filter(
        ([, courseData]) =>
          courseData.isIlt === true && courseData.talentLmsId !== null,
      )
      .map(([courseName, courseData]) => ({
        name: courseName,
        talentLmsId: courseData.talentLmsId as number,
        units: courseData.iltUnits.map((unit) => ({
          id: unit.id,
          name: unit.name,
        })),
      }));

    /* =====================================================
     * 9. CONSTRUIR MAP DOS USERS DOS CURSOS ILT
     * ===================================================== */

    const users = new Map<string, UserAnalysisData>();

    const totalIltRows = iltCoursesData.reduce(
      (total, courseData) => total + courseData.rows.length,
      0,
    );

    let checkedRows = 0;

    for (const courseData of iltCoursesData) {
      for (const rowNumber of courseData.rows) {
        const row = worksheet.getRow(rowNumber);
        const employeeNumber = row.getCell(employeeColumnNumber).text.trim();

        const firstName =
          firstNameColumnNumber !== null
            ? row.getCell(firstNameColumnNumber).text.trim()
            : "";

        const lastName =
          lastNameColumnNumber !== null
            ? row.getCell(lastNameColumnNumber).text.trim()
            : "";

        if (employeeNumber) {
          const existingUser = users.get(employeeNumber);

          if (existingUser) {
            existingUser.rows.push(rowNumber);

            if (!existingUser.firstName && firstName) {
              existingUser.firstName = firstName;
            }

            if (!existingUser.lastName && lastName) {
              existingUser.lastName = lastName;
            }
          } else {
            users.set(employeeNumber, {
              rows: [rowNumber],
              firstName,
              lastName,
              talentLmsUserId: null,
              iltProgress: [],
            });
          }
        }

        checkedRows++;

        if (checkedRows % 100 === 0 || checkedRows === totalIltRows) {
          event.sender.send("analysis:progress", {
            stage: "checkingUsers",
            current: checkedRows,
            total: totalIltRows,
          });

          await new Promise<void>((resolve) => setImmediate(resolve));
        }
      }
    }

    /* =====================================================
     * 10. ASSOCIAR EMPLOYEE NUMBER -> TALENTLMS USER ID
     * ===================================================== */

    let matchedUsers = 0;
    let checkedUsers = 0;

    const unmatchedUsers: string[] = [];
    const userEntries = Array.from(users.entries());
    const USER_BATCH_SIZE = 2;

    for (let i = 0; i < userEntries.length; i += USER_BATCH_SIZE) {
      const batch = userEntries.slice(i, i + USER_BATCH_SIZE);

      const results = await Promise.all(
        batch.map(async ([employeeNumber, userData]) => {
          const talentLmsUserId = await getUserIdByEmployeeNumber(
            talentLmsConfig,
            employeeNumber,
          );

          return {
            employeeNumber,
            userData,
            talentLmsUserId,
          };
        }),
      );

      for (const item of results) {
        item.userData.talentLmsUserId = item.talentLmsUserId;

        if (item.talentLmsUserId !== null) {
          matchedUsers++;
        } else {
          unmatchedUsers.push(item.employeeNumber);
        }

        checkedUsers++;

        event.sender.send("analysis:progress", {
          stage: "matchingUsers",
          current: checkedUsers,
          total: users.size,
        });
      }
    }

    /* =====================================================
     * 11. CRIAR JOBS USER + UNIT
     * ===================================================== */

    const unitProgressJobs: {
      employeeNumber: string;
      userData: UserAnalysisData;
      userId: number;
      courseId: number;
      courseName: string;
      unitId: number;
      unitName: string;
    }[] = [];

    for (const [courseName, courseData] of courses) {
      if (courseData.isIlt !== true || courseData.talentLmsId === null) {
        continue;
      }

      const courseEmployeeNumbers = new Set<string>();

      for (const rowNumber of courseData.rows) {
        const row = worksheet.getRow(rowNumber);
        const employeeNumber = row.getCell(employeeColumnNumber).text.trim();

        if (employeeNumber) {
          courseEmployeeNumbers.add(employeeNumber);
        }
      }

      for (const employeeNumber of courseEmployeeNumbers) {
        const userData = users.get(employeeNumber);

        if (!userData || userData.talentLmsUserId === null) {
          continue;
        }

        for (const unit of courseData.iltUnits) {
          unitProgressJobs.push({
            employeeNumber,
            userData,
            userId: userData.talentLmsUserId,
            courseId: courseData.talentLmsId,
            courseName,
            unitId: unit.id,
            unitName: unit.name,
          });
        }
      }
    }

    console.log("TOTAL UNIT PROGRESS JOBS:", unitProgressJobs.length);
    console.log("PRIMEIROS JOBS:", unitProgressJobs.slice(0, 5));

    /* =====================================================
     * 12. DEV MODE / JOBS A PROCESSAR
     * ===================================================== */

    const jobsToProcess = IS_DEV_TEST
      ? unitProgressJobs.slice(0, DEV_PROGRESS_LIMIT)
      : unitProgressJobs;

    console.log(
      IS_DEV_TEST
        ? `DEV MODE: vamos processar apenas ${jobsToProcess.length} de ${unitProgressJobs.length} jobs`
        : `PRODUCTION MODE: vamos processar ${jobsToProcess.length} jobs`,
    );

    /* =====================================================
     * 13. OBTER UNIT PROGRESS
     * ===================================================== */

    let checkedUnitProgress = 0;
    const UNIT_PROGRESS_BATCH_SIZE = 2;

    for (let i = 0; i < jobsToProcess.length; i += UNIT_PROGRESS_BATCH_SIZE) {
      const batch = jobsToProcess.slice(i, i + UNIT_PROGRESS_BATCH_SIZE);

      const results = await Promise.all(
        batch.map(async (job) => {
          const progress = await getUnitProgress(
            talentLmsConfig,
            job.userId,
            job.unitId,
          );

          return {
            job,
            progress,
          };
        }),
      );

      for (const item of results) {
        item.job.userData.iltProgress.push({
          courseId: item.job.courseId,
          courseName: item.job.courseName,
          unitId: item.job.unitId,
          unitName: item.job.unitName,
          status: item.progress?.status ?? "not_enrolled",
          totalTime: item.progress?.totalTime ?? 0,
        });

        checkedUnitProgress++;

        event.sender.send("analysis:progress", {
          stage: "checkingUnitProgress",
          current: checkedUnitProgress,
          total: jobsToProcess.length,
        });
      }

      await new Promise<void>((resolve) => setTimeout(resolve, 250));
    }

    /* =====================================================
     * 14. ESTATÍSTICAS DE PROGRESSO
     * ===================================================== */

    let completedCount = 0;
    let failedCount = 0;
    let notAttemptedCount = 0;
    let notEnrolledCount = 0;

    for (const userData of users.values()) {
      for (const progress of userData.iltProgress) {
        if (progress.status === "completed") {
          completedCount++;
        } else if (progress.status === "failed") {
          failedCount++;
        } else if (progress.status === "not_attempted") {
          notAttemptedCount++;
        } else if (progress.status === "not_enrolled") {
          notEnrolledCount++;
        }
      }
    }

    const notCheckedCount = Math.max(
      unitProgressJobs.length - jobsToProcess.length,
      0,
    );

    /* =====================================================
     * 15. REORGANIZAR RESULTADOS:
     * CURSO -> UNIT LÓGICA -> PESSOAS
     * ===================================================== */

    const courseProgressDetails: CourseProgressDetails[] = [];

    for (const [courseName, courseData] of courses) {
      if (courseData.isIlt !== true || courseData.talentLmsId === null) {
        continue;
      }

      /*
       * Colaboradores que pertencem a este curso
       */
      const courseEmployeeNumbers = new Set<string>();

      for (const rowNumber of courseData.rows) {
        const row = worksheet.getRow(rowNumber);

        const employeeNumber = row.getCell(employeeColumnNumber).text.trim();

        if (employeeNumber) {
          courseEmployeeNumbers.add(employeeNumber);
        }
      }

      /*
       * =====================================================
       * AGRUPAR UNITS FÍSICAS PELO NOME
       * =====================================================
       *
       * Exemplo:
       *
       * 3326 -> hômaboarding - Caixa
       * 3332 -> hômaboarding - Caixa
       *
       * tornam-se:
       *
       * hômaboarding - Caixa
       *   physicalUnits: [3326, 3332]
       */

      const logicalUnitsMap = new Map<
        string,
        {
          name: string;
          physicalUnits: IltUnitData[];
        }
      >();

      for (const unit of courseData.iltUnits) {
        const logicalKey = normalizeUnitName(unit.name);

        const existingLogicalUnit = logicalUnitsMap.get(logicalKey);

        if (existingLogicalUnit) {
          existingLogicalUnit.physicalUnits.push(unit);
        } else {
          logicalUnitsMap.set(logicalKey, {
            name: unit.name.trim(),
            physicalUnits: [unit],
          });
        }
      }

      console.log(
        `Curso ${courseName}: ${courseData.iltUnits.length} ILTs físicas -> ${logicalUnitsMap.size} ILTs lógicas`,
      );

      /*
       * =====================================================
       * CONSTRUIR RESULTADO DE CADA UNIT LÓGICA
       * =====================================================
       */

      const units: CourseProgressUnit[] = [];

      for (const logicalUnit of logicalUnitsMap.values()) {
        const unitUsers: CourseProgressUser[] = [];

        for (const employeeNumber of courseEmployeeNumbers) {
          const userData = users.get(employeeNumber);

          if (!userData) {
            continue;
          }

          /*
           * Todos os progressos deste utilizador
           * correspondentes a QUALQUER ID físico
           * desta unidade lógica.
           */
          const physicalUnitIds = new Set(
            logicalUnit.physicalUnits.map((unit) => unit.id),
          );

          const matchingProgress = userData.iltProgress.filter(
            (progress) =>
              progress.courseId === courseData.talentLmsId &&
              physicalUnitIds.has(progress.unitId),
          );

          let status = "not_checked";
          let totalTime = 0;

          if (userData.talentLmsUserId === null) {
            status = "user_not_found";
          } else if (matchingProgress.length > 0) {
            /*
             * Se tiver completado QUALQUER ocorrência
             * da mesma unidade lógica,
             * consideramos esta formação concluída.
             */

            const completedProgress = matchingProgress.find(
              (progress) => progress.status === "completed",
            );

            if (completedProgress) {
              status = "completed";

              /*
               * Se existirem várias ocorrências completed,
               * somamos os tempos registados.
               *
               * Isto pode ser ajustado depois das regras
               * finais da hôma.
               */
              totalTime = matchingProgress
                .filter((progress) => progress.status === "completed")
                .reduce((total, progress) => total + progress.totalTime, 0);
            } else {
              const pendingProgress = matchingProgress.find(
                (progress) => progress.status === "pending",
              );

              const failedProgress = matchingProgress.find(
                (progress) => progress.status === "failed",
              );

              const notAttemptedProgress = matchingProgress.find(
                (progress) => progress.status === "not_attempted",
              );

              const notEnrolledProgress = matchingProgress.find(
                (progress) => progress.status === "not_enrolled",
              );

              if (pendingProgress) {
                status = "pending";
                totalTime = pendingProgress.totalTime;
              } else if (failedProgress) {
                status = "failed";
                totalTime = failedProgress.totalTime;
              } else if (notAttemptedProgress) {
                status = "not_attempted";

                totalTime = 0;
              } else if (notEnrolledProgress) {
                status = "not_enrolled";

                totalTime = 0;
              }
            }
          }

          unitUsers.push({
            employeeNumber,

            firstName: userData.firstName,

            lastName: userData.lastName,

            talentLmsUserId: userData.talentLmsUserId,

            status,

            totalTime,
          });
        }

        /*
         * Como esta é agora uma UNIT LÓGICA,
         * usamos o primeiro ID físico apenas
         * como identificador estável para o frontend.
         */
        const representativeUnit = logicalUnit.physicalUnits[0];

        units.push({
          unitId: representativeUnit.id,

          unitName: logicalUnit.name,

          users: unitUsers,
        });
      }

      courseProgressDetails.push({
        courseId: courseData.talentLmsId,

        courseName,

        units,
      });
    }

    /* =====================================================
     * 16. CURSOS NÃO ENCONTRADOS
     * ===================================================== */

    const unmatchedCourses: string[] = [];
    let matchedCourses = 0;

    for (const [courseName, courseData] of courses) {
      if (courseData.talentLmsId !== null) {
        matchedCourses++;
      } else {
        unmatchedCourses.push(courseName);
      }
    }

    currentAnalysis = {
      filePath,
      workbook,
      worksheet,
      courses,
      users,
    };

    /* =====================================================
     * 17. ENVIAR RESUMO PARA O FRONTEND
     * ===================================================== */

    return {
      cancelled: false,
      summary: {
        fileName: path.basename(filePath),
        sheetName: worksheet.name,
        totalRows: Math.max(worksheet.actualRowCount - DATA_START_ROW + 1, 0),
        totalColumns: columns.length,
        columns,
        courses: uniqueCourses,

        matchedCourses,
        unmatchedCourses,

        iltCourses,
        iltCourseDetails,
        courseProgressDetails,

        uniqueUsers: users.size,
        matchedUsers,
        unmatchedUsers,

        progressStats: {
          totalJobs: unitProgressJobs.length,
          processedJobs: jobsToProcess.length,
          completed: completedCount,
          failed: failedCount,
          notAttempted: notAttemptedCount,
          notEnrolled: notEnrolledCount,
          notChecked: notCheckedCount,
        },
      },
    };
  } catch (error) {
    console.error("Erro durante a análise:", error);

    return {
      cancelled: false,
      error:
        error instanceof Error
          ? `Não foi possível concluir a análise: ${error.message}`
          : "Não foi possível concluir a análise.",
    };
  }
});

app.whenReady().then(createWindow);

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") {
    app.quit();
  }
});

app.on("activate", () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});
